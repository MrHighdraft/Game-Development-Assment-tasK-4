let currentQuestion = 0;
let score = 0;
const questions = [
    {
        question: "What is the best way to reduce plastic pollution?",
        options: ["Recycle", "Reuse", "Reduce", "All of the above"],
        answer: 4
    },
    {
        question: "What gas do plants absorb from the atmosphere?",
        options: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"],
        answer: 2
    },
    {
        question: "Which is a renewable source of energy?",
        options: ["Coal", "Oil", "Solar", "Natural Gas"],
        answer: 3
    },
    {
        question: "What percentage of Earth is covered in water?",
        options: ["50%", "60%", "70%", "80%"],
        answer: 3
    },
    {
        question: "What is a common consequence of deforestation?",
        options: ["Increased biodiversity", "Loss of habitat", "Decreased carbon emissions", "None of the above"],
        answer: 2
    }
];

function startGame() {
    document.getElementById('homeScreen').style.display = 'none';
    document.getElementById('quizScreen').style.display = 'block';
    loadQuestion();
}

function loadQuestion() {
    if (currentQuestion < questions.length) {
        document.getElementById('question').textContent = questions[currentQuestion].question;
        const options = document.getElementById('options').children;
        for (let i = 0; i < options.length; i++) {
            options[i].textContent = questions[currentQuestion].options[i];
        }
        document.getElementById('feedback').textContent = '';
        document.getElementById('nextButton').style.display = 'none';
    } else {
        endGame();
    }
}

function checkAnswer(option) {
    if (option === questions[currentQuestion].answer) {
        document.getElementById('feedback').textContent = 'Correct! You earned 10 points.';
        score += 10;
    } else {
        document.getElementById('feedback').textContent = 'Wrong!';
    }
    document.getElementById('nextButton').style.display = 'block';
}

function nextQuestion() {
    currentQuestion++;
    loadQuestion();
}

function endGame() {
    document.getElementById('quizScreen').style.display = 'none';
    document.getElementById('endScreen').style.display = 'block';
    document.getElementById('finalScore').textContent = score;
}

function restartGame() {
    currentQuestion = 0;
    score = 0;
    document.getElementById('endScreen').style.display = 'none';
    document.getElementById('homeScreen').style.display = 'block';
}
